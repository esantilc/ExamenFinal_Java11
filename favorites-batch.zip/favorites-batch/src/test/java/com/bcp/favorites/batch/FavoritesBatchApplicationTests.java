package com.bcp.favorites.batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavoritesBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
