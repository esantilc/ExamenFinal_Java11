package com.bcp.favorites.batch.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Favorites")
public class FavoriteSource {

	@Id
	private String id;
	private String favoriteGroupsId;
	private String iconCod;
	private String productData;
	private String alias;
	private String operationCod;
	private Date updateDate;
	private Date registrationDate;
	private String state;
	private String email;
	private String applicationCode;

	
	public FavoriteSource() {}
	
	public FavoriteSource(String id, String favoriteGroupsId, String iconCod, String productData, String alias,
			String operationCod, Date updateDate, Date registrationDate, String state, String email,
			String applicationCode) {
		super();
		this.id = id;
		this.favoriteGroupsId = favoriteGroupsId;
		this.iconCod = iconCod;
		this.productData = productData;
		this.alias = alias;
		this.operationCod = operationCod;
		this.updateDate = updateDate;
		this.registrationDate = registrationDate;
		this.state = state;
		this.email = email;
		this.applicationCode = applicationCode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFavoriteGroupsId() {
		return favoriteGroupsId;
	}

	public void setFavoriteGroupsId(String favoriteGroupsId) {
		this.favoriteGroupsId = favoriteGroupsId;
	}

	public String getIconCod() {
		return iconCod;
	}

	public void setIconCod(String iconCode) {
		this.iconCod = iconCode;
	}

	public String getProductData() {
		return productData;
	}

	public void setProductData(String productData) {
		this.productData = productData;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getOperationCod() {
		return operationCod;
	}

	public void setOperationCod(String operationCod) {
		this.operationCod = operationCod;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	@Override
	public String toString() {
		return "Favorite [id=" + id + ", alias=" + alias + ", operationCod=" + operationCod + ", registrationDate="
				+ registrationDate + ", state=" + state + "]";
	}
	
	
}
