package com.bcp.favorites.batch.model;

public class Operation {

	private String operationCod;
	private OperationType operationType;
	
	public Operation(String operationCod, OperationType operationType) {
		super();
		this.operationCod = operationCod;
		this.operationType = operationType;
	}

	public String getOperationCod() {
		return operationCod;
	}

	public void setOperationCod(String operationCod) {
		this.operationCod = operationCod;
	}

	public OperationType getOperationType() {
		return operationType;
	}

	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}

}
