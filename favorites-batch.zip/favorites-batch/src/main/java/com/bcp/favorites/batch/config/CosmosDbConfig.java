package com.bcp.favorites.batch.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.azure.data.cosmos.ConnectionPolicy;
import com.microsoft.azure.spring.data.cosmosdb.config.AbstractCosmosConfiguration;
import com.microsoft.azure.spring.data.cosmosdb.config.CosmosDBConfig;
import com.microsoft.azure.spring.data.cosmosdb.core.CosmosTemplate;
import com.microsoft.azure.spring.data.cosmosdb.repository.config.EnableCosmosRepositories;

@Configuration
@EnableCosmosRepositories(basePackages = "com.bcp.favorites.batch.repositories.target")
@ComponentScan(basePackages = "com.bcp.favorites.batch.repositories.target")
public class CosmosDbConfig extends AbstractCosmosConfiguration {

	/*
	 * @Bean(name = "CosmosDb") public CosmosDBConfig
	 * getCosmosDbConfig(@Value("${azure.cosmosdb.uri}") String host,
	 * 
	 * @Value("${azure.cosmosdb.key}") String
	 * key, @Value("${azure.cosmosdb.database}") String database) { ConnectionPolicy
	 * connectionPolicy = new ConnectionPolicy(); connectionPolicy.connectionMode()
	 * return CosmosDBConfig.builder(host, key, database).build(); }
	 */

	@Primary
	@Bean(name = "CosmosDbTemplate")
	public CosmosTemplate cosmosTemplate(/* @Qualifier("CosmosDb") */CosmosDBConfig config)
			throws ClassNotFoundException {
		return super.cosmosTemplate(config);
	}
}
