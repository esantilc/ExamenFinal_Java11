package com.bcp.favorites.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
//@EnableMongoRepositories(basePackages = "com.bcp.favorites.batch.repository")
public class FavoritesBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(FavoritesBatchApplication.class, args);
		System.out.println("Probando datasource");
	}

}
