//	package com.bcp.favorites.batch.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
//import org.springframework.core.io.FileSystemResource;
//
//@Configuration
//public class ExternalPropertyConfigurer {
//
//    @Bean
//    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
//        PropertySourcesPlaceholderConfigurer properties = new PropertySourcesPlaceholderConfigurer();
//        properties.setLocation(new FileSystemResource("D:/eclipse-workspace/everis/application.properties"));
//        properties.setIgnoreResourceNotFound(false);
//        return properties;-}
//}