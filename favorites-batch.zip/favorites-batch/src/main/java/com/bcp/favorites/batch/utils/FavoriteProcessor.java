package com.bcp.favorites.batch.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.bcp.favorites.batch.model.FavoriteSource;
import com.bcp.favorites.batch.model.FavoriteTarget;

public class FavoriteProcessor implements ItemProcessor<FavoriteSource, FavoriteTarget>{

	private static final Logger LOGGER = LoggerFactory.getLogger(FavoriteProcessor.class);
	
	@Override
	public FavoriteTarget process(FavoriteSource item) throws Exception {
        LOGGER.info("Processing student information: {}", item);
        FavoriteTarget favoriteTarget = new FavoriteTarget();
        favoriteTarget.setMongoDb(item.getId());
        favoriteTarget.setFavoriteGroupsId(item.getFavoriteGroupsId());
        favoriteTarget.setIconCod(item.getIconCod());
        favoriteTarget.setProductData(item.getProductData());
        favoriteTarget.setAlias(item.getAlias());
        favoriteTarget.setOperationCod(item.getOperationCod());
        favoriteTarget.setRegistrationDate(item.getRegistrationDate());
        favoriteTarget.setUpdateDate(item.getUpdateDate());
        favoriteTarget.setState(item.getState());
        favoriteTarget.setEmail(item.getEmail());
        favoriteTarget.setApplicationCode(item.getApplicationCode());
        
        return favoriteTarget;
	}

}
