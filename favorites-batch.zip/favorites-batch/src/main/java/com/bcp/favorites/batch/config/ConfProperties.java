package com.bcp.favorites.batch.config;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConfProperties {
	
	@Value("${resource-path}")
	private String resourcePath;

	@Value("#{new java.text.SimpleDateFormat(\"yyyyMMdd\").parse(\"${last-execute-date}\")}")
	private Date lastDateExecute;

	public String getResourcePath() {
		return resourcePath;
	}

	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	public Date getLastDateExecute() {
		return lastDateExecute;
	}

	public void setLastDateExecute(Date lastDateExecute) {
		this.lastDateExecute = lastDateExecute;
	}
	
	

}
