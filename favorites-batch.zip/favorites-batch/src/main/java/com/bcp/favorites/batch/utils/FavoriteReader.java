package com.bcp.favorites.batch.utils;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import com.bcp.favorites.batch.model.FavoriteSource;
import com.bcp.favorites.batch.repositories.source.FavoriteSourceRepository;

public class FavoriteReader implements ItemReader<FavoriteSource> {

	private static Logger LOG = LoggerFactory.getLogger(FavoriteReader.class);

	private FavoriteSourceRepository favoriteRepository;

	private List<FavoriteSource> favoriteData;

	private int nextFavoriteIndex;

	private Date lastDateExecute;

	public FavoriteReader(FavoriteSourceRepository favoriteRepository, Date lastDateExecute) {
		this.favoriteRepository = favoriteRepository;
		nextFavoriteIndex = 0;
		this.lastDateExecute = lastDateExecute;
	}

	@Override
	public FavoriteSource read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {		
		if (favoriteDataIsNotInitialized()) {
			Date currentDate = new Date();
			favoriteData = favoriteRepository.listByParameter(lastDateExecute, currentDate);
			System.out.println("TOTAL:!!! "+ favoriteData.size());
		}
		FavoriteSource nextFavorite = null;

		if (nextFavoriteIndex < favoriteData.size()) {
			nextFavorite = favoriteData.get(nextFavoriteIndex);
			LOG.info("Found student: {}", nextFavorite);
			nextFavoriteIndex++;
		}

		return nextFavorite;
	}

	private boolean favoriteDataIsNotInitialized() {
		return this.favoriteData == null;
	}
}
