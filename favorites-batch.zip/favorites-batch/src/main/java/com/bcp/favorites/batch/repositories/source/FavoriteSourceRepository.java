package com.bcp.favorites.batch.repositories.source;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.bcp.favorites.batch.model.FavoriteSource;

@Repository
public interface FavoriteSourceRepository extends MongoRepository<FavoriteSource, String> {

	//@Query("{$and: [{'operationCod': { $in: [?0] }}, {'registrationDate': {$gte: ?1}}]}")	
	@Query("{'updateDate': {$gte: ?0, $lte: ?1}}")	
	List<FavoriteSource> listByParameter(Date lastDateExecute, Date currentDate);

}
