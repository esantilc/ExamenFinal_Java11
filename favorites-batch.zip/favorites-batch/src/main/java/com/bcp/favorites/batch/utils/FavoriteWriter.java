package com.bcp.favorites.batch.utils;

import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.core.io.FileSystemResource;

import com.bcp.favorites.batch.model.FavoriteSource;
import com.bcp.favorites.batch.model.FavoriteTarget;

public class FavoriteWriter extends FlatFileItemWriter<FavoriteTarget> {

	String resourcePath;

	public FavoriteWriter(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	public FlatFileItemWriter<FavoriteTarget> write() {

		FlatFileItemWriter<FavoriteTarget> writer = new FlatFileItemWriter<FavoriteTarget>();
		writer.setResource(new FileSystemResource(resourcePath));
		writer.setShouldDeleteIfExists(true);
		writer.setLineAggregator(new DelimitedLineAggregator<FavoriteTarget>() {
			{
				setDelimiter(",");
				setFieldExtractor(new BeanWrapperFieldExtractor<FavoriteTarget>() {
					{

						setNames(new String[] { "favoriteGroupsId", "iconCod", "productData", "alias",
								"operationCod", "registrationDate", "updateDate", "state" });

						// setNames(new String[] { "operationCod", "updateDate", "registrationDate",
						// "state" });

					}
				});
			}
		});
		return writer;
	}

}
