package com.bcp.favorites.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bcp.favorites.batch.config.ConfProperties;
import com.bcp.favorites.batch.listener.JobListener;
import com.bcp.favorites.batch.model.FavoriteSource;
import com.bcp.favorites.batch.model.FavoriteTarget;
import com.bcp.favorites.batch.repositories.source.FavoriteSourceRepository;
import com.bcp.favorites.batch.utils.FavoriteProcessor;
import com.bcp.favorites.batch.utils.FavoriteReader;
import com.bcp.favorites.batch.utils.FavoriteWriter;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private FavoriteSourceRepository favoriteRepository;

	@Autowired
	private ConfProperties properties;

	@Bean
	public Step inMemoryFavoriteStep() {

		return stepBuilderFactory.get("inMemoryFavoriteStep").<FavoriteSource, FavoriteTarget>chunk(10)
				.reader(new FavoriteReader(favoriteRepository, properties.getLastDateExecute())).processor(new FavoriteProcessor())
				.writer(new FavoriteWriter(properties.getResourcePath()).write()).build();
	}

	@Bean
	Job inMemoryFavoriteJob(Step inMemoryFavoriteStep, JobListener listener) {
		return jobBuilderFactory.get("inMemoryFavoriteJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(inMemoryFavoriteStep).end().build();
	}
}
