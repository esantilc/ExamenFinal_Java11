package com.bcp.favorites.batch.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackages =  "com.bcp.favorites.batch.repositories.source")
@ComponentScan(basePackages =  "com.bcp.favorites.batch.repositories.source")
public class MongoDbConfig {

	/*
	 * @Bean public MongoDatabaseFactory mongoDbFactory() { MongoClient mongoClient
	 * = MongoClients.create(); return new
	 * SimpleMongoClientDatabaseFactory(mongoClient, "exampledb"); }
	 * 
	 * @Bean public MongoTemplate mongoTemplate() { return new
	 * MongoTemplate(mongoDbFactory()); }
	 */

}
