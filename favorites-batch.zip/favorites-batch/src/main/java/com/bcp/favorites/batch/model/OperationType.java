package com.bcp.favorites.batch.model;

public enum OperationType {

	BCP,
	SERVICIOS,
	INTERBANCARIAS,
	GIROSNACIONALES,
	TRANSFERENCIASEXTERIOR,
	SUNAT
}
